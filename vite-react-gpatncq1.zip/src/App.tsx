import React from 'react';
import CustomsGlobe from './CustomsGlobe';

function App() {
  return <CustomsGlobe />;
}

export default App;
